package com.cg.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;

public interface MACService {
	public List <ProgramScheduled> getAllScheduledPrograms();
	public String updateStatus(String status,int id);
	public int setInterviewDate(LocalDate date,int id);
	public List<Application> showApplicationByStatus(String status);
	public List<Application> getAllApplications();
	public String ReturnStatus(int id);
	public boolean isValidDoi(String doi);
}
