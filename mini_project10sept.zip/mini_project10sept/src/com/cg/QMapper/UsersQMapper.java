package com.cg.QMapper;

public interface UsersQMapper {
	public static final String SELECT_PWD_usingID = "SELECT PASSWORD FROM USERS WHERE LOGIN_ID=?";
	public static final String SELECT_ROLE_usingID = "SELECT ROLE FROM USERS WHERE LOGIN_ID=?";
}
