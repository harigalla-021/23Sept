package com.cg.client;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.Exception.UASException;
import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;
import com.cg.service.ApplicantService;
import com.cg.service.ApplicantServiceImpl;
import com.cg.util.MyStringDateUtil;

public class ApplicantMain {

	ApplicantService service = null;

	public void NewApplication() {
		Scanner sc = new Scanner(System.in);
		service = new ApplicantServiceImpl();
		int choice = -1;
		while (true) {
			System.out.println("\n\n**************************************************");
			System.out.println("\nSelect an Option:");
			System.out.println("\t1. View List of Scheduled Programs\n\t" + "2. Apply for a Program\n\t"
					+ "3. Track Application Status");
			System.out.println("\n**************************************************");
			System.out.println("Enter 0 to Return");
			System.out.println("Enter your choice:");
			choice = Integer.parseInt(sc.nextLine());

			switch (choice) {

			case 1:
				System.out.println("\n\n*****List of Scheduled Programs****");
				List<ProgramScheduled> list = service.getAllScheduledPrograms();
				Iterator<ProgramScheduled> iterator = list.iterator();
				ProgramScheduled ps;
				System.out.format("\t%-30s %-20s %-20s %-20s %-20s %-20s", "SCHEDULED PROGRAM ID", "PROGRAM NAME",
						"LOCATION", "START DATE", "END DATE", "SESSIONS/WEEK");
				while (iterator.hasNext()) {
					ps = iterator.next();
					System.out.println("");
					System.out.format("\t%-30s %-20s %-20s %-20s %-20s %-20s", ps.getScheduledProgramId(),
							ps.getProgramName(), ps.getLocation(), ps.getStartDate(), ps.getEndDate(),
							ps.getSessionsPerWeek());
				}
				break;

			case 2:
				System.out.println("\n \nEnter details to apply for the selected Program.");
				Application applicant = new Application();
				String str = null;
				do {
					System.out.println("\t\t1. Full Name: ");
					str = sc.nextLine();
					applicant.setFullName(str);
					if (!service.isValidName(str))
						System.out.println("Please Enter  valid Name:");
				} while (!service.isValidName(str));

				do {
					System.out.println("\t\t2. Date of Birth in dd-MM-yyyy format:");
					str = sc.nextLine();
					if (!service.isValidDob(str))
						System.out.println("Please Enter a Valid DOB:");
				} while (!service.isValidDob(str));
				applicant.setDateOfBirth(MyStringDateUtil.fromStringToLocalDate(str));

				String qualification = null;
				do {
					System.out.println("\t\t3. Choose Highest Qualification..." + "\n\t\t\t (a) B.Tech"
							+ "\n\t\t\t (b) B.Sc" + "\n\t\t\t (c) B.Pharm." + "\n\t\t\t (d) BCA" + "\n\t\t\t (e) MCA");

					char ch = sc.nextLine().charAt(0);
					if (ch == 'a')
						qualification = "B.Tech";
					else if (ch == 'b')
						qualification = "B.Sc";
					else if (ch == 'c')
						qualification = "B.Pharm";
					else if (ch == 'd')
						qualification = "BCA";
					else if (ch == 'e')
						qualification = "MCA";

					applicant.setHighestQualification(qualification);
					if (qualification == null)
						System.out.println("Please enter a Valid Character");
				} while ((qualification == null));

				int marks;

				do {
					System.out.println("\n\t\t4. Marks Obtained (*/100):");
					marks = Integer.parseInt(sc.nextLine());
					applicant.setMarksObtained(marks);
					if (!service.isValidMarks(marks))
						System.out.println("Please Enter a Valid Number:");
				} while (!service.isValidMarks(marks));

				do {
					System.out.println("\n\t\t5. Goals:");
					str = sc.nextLine();
					applicant.setGoals(str);
					if (!service.isValidGoals(str))
						System.out.println("Please Enter atleast 3 characters:");
				} while (!service.isValidGoals(str));

				do {
					System.out.println("\n\t\t6. Email-Id:");
					str = sc.nextLine();
					applicant.setEmailId(str);
					if (!service.isValidEmailId(str))
						System.out.println("Please Enter a Valid Email:");
				} while (!service.isValidEmailId(str));

				System.out.println("\n\t\t7. Scheduled Programs:");
				ArrayList<String> list3 = service.getScheduledProgramId();
				Iterator<String> iterator3 = list3.iterator();
				while (iterator3.hasNext())
					System.out.println("\t" + iterator3.next());

				do {
					System.out.println("\n\nEnter a Program from Above: ");
					str = sc.nextLine().toUpperCase();
					applicant.setScheduledProgramId(str);
					if (!service.isValidScheduleProgId(str))
						System.out.println("Please Enter a Valid Program:");
				} while (!service.isValidScheduleProgId(str));

				try {
					if (service.addApplication(applicant) != 0) {

						System.out.println("Application added Successfully!");
					} else
						System.out.println("Error! during application process.");
				} catch (UASException e) {
					System.out.println(e.getMessage());
				}

				break;

			case 3:
				System.out.println("\n\t\tEnter the application id:");
				int id = Integer.parseInt(sc.nextLine());
				String status = service.applicationStatus(id);
				System.out.println("Application status: " + status);
				break;

			case 0:
				return;

			default:
				System.out.println("Sorry ! invalid keystroke... try again");

			}
		}
	}
}
